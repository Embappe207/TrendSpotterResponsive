
const fetch = require('node-fetch');
const SLACK_WEBHOOK_URL = 'https://hooks.slack.com/services/TU/CODIGO/WEBHOOK';

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { user, item, amount } = req.body;
    await fetch(SLACK_WEBHOOK_URL, {
      method: 'POST',
      body: JSON.stringify({ text: `🛒 Nueva compra: ${user} compró ${item} por $${amount}` }),
      headers: { 'Content-Type': 'application/json' }
    });
    res.status(200).json({ ok: true });
  } else {
    res.status(405).json({ error: 'Método no permitido' });
  }
}
