// i18n config placeholder
