import DashboardMultilingual from './DashboardMultilingual';
export default function App(){return <DashboardMultilingual />;}